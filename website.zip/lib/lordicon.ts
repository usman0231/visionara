"use client";

import lottie from "lottie-web";
import { defineElement } from "lord-icon-element";

// define the custom element
defineElement(lottie.loadAnimation);
